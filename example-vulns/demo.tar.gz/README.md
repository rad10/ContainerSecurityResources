Start by building the compose as placed in this space, then run `shells.sh` to
add the necessary backdoors
